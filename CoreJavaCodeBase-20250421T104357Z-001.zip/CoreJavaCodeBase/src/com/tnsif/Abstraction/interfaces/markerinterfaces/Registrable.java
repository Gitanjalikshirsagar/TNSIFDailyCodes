//Program to demonstrate Marker Interface
package com.tnsif.dayeight.interfaces.markerinterfaces;

public interface Registrable {

}
